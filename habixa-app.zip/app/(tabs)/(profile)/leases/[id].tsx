import { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Pressable,
  ScrollView,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { HabixaIcon } from '@/components/HabixaIcon';
import { Colors, Fonts } from '@/constants/theme';
import { api, Endpoints } from '@/lib/api/client';

interface Listing {
  id: number;
  title?: string;
  address?: string;
  city?: string;
  state?: string;
  country?: string;
  price?: string | number;
  currency?: string;
}

interface Lease {
  id: number;
  listing_id: number;
  landlord_id: number;
  tenant_id: number;
  start_date: string;
  end_date: string;
  monthly_rent: string | number;
  status: string;
  tenant_confirmed_at?: string | null;
  created_at: string;
  listing?: Listing;
  landlord?: { id: number; name: string; email?: string };
  tenant?: { id: number; name: string; email?: string };
}

interface LeasePayment {
  id: number;
  amount: string | number;
  currency?: string;
  status: string;
  created_at: string;
}

function formatDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

function formatCurrency(amount: string | number): string {
  const n = typeof amount === 'string' ? parseFloat(amount) : amount;
  return new Intl.NumberFormat(undefined, {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(n);
}

export default function LeaseDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const { user } = useAuth();

  const [lease, setLease] = useState<Lease | null>(null);
  const [leasePayments, setLeasePayments] = useState<LeasePayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [confirming, setConfirming] = useState(false);

  useEffect(() => {
    if (!id) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    api
      .get<Lease>(Endpoints.leases.show(id))
      .then((data) => {
        if (!cancelled) setLease(data);
      })
      .catch((e: { message?: string }) => {
        if (!cancelled) setError(e?.message ?? 'Failed to load lease');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => { cancelled = true; };
  }, [id]);

  useEffect(() => {
    if (!id || !lease) return;
    let cancelled = false;
    api
      .get<LeasePayment[]>(Endpoints.leases.payments(id))
      .then((data) => {
        if (!cancelled) setLeasePayments(Array.isArray(data) ? data : []);
      })
      .catch(() => {
        if (!cancelled) setLeasePayments([]);
      });
    return () => { cancelled = true; };
  }, [id, lease?.id]);

  const handleConfirm = async () => {
    if (!id || !user) return;
    setConfirming(true);
    try {
      await api.post(Endpoints.leases.confirm(id));
      setLease((prev) =>
        prev ? { ...prev, status: 'active', tenant_confirmed_at: new Date().toISOString() } : null
      );
      Alert.alert('Success', 'Lease confirmed successfully.');
    } catch (e) {
      const err = e as { message?: string };
      Alert.alert('Error', err?.message ?? 'Failed to confirm lease');
    } finally {
      setConfirming(false);
    }
  };

  const isTenant = user && lease && lease.tenant_id === user.id;
  const canConfirm = isTenant && lease?.status === 'pending' && !lease?.tenant_confirmed_at;
  const canPayRent = isTenant && lease?.status === 'active';

  const getListingTitle = (): string => {
    return lease?.listing?.title ?? lease?.listing?.address ?? `Listing #${lease?.listing_id}`;
  };

  const getAddress = (): string => {
    const l = lease?.listing;
    if (!l) return '';
    const parts = [l.address, l.city, l.state, l.country].filter(Boolean);
    return parts.join(', ') || '';
  };

  if (loading) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, backgroundColor: colors.background }]}>
        <View style={[styles.header, { borderBottomColor: colors.border }]}>
          <Pressable onPress={() => router.back()} style={styles.backBtn}>
            <Text style={[styles.backText, { color: Colors.terracotta }]}>← Back</Text>
          </Pressable>
          <Text style={[styles.title, { color: colors.text }]}>Lease Details</Text>
        </View>
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="large" color={Colors.terracotta} />
        </View>
      </View>
    );
  }

  if (error || !lease) {
    return (
      <View style={[styles.container, { paddingTop: insets.top, backgroundColor: colors.background }]}>
        <View style={[styles.header, { borderBottomColor: colors.border }]}>
          <Pressable onPress={() => router.back()} style={styles.backBtn}>
            <Text style={[styles.backText, { color: Colors.terracotta }]}>← Back</Text>
          </Pressable>
          <Text style={[styles.title, { color: colors.text }]}>Lease Details</Text>
        </View>
        <View style={styles.emptyWrap}>
          <HabixaIcon name="exclamation-circle" size={48} color={Colors.muted} />
          <Text style={[styles.emptyTitle, { color: colors.text }]}>{error ?? 'Lease not found'}</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top, backgroundColor: colors.background }]}>
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Text style={[styles.backText, { color: Colors.terracotta }]}>← Back</Text>
        </Pressable>
        <Text style={[styles.title, { color: colors.text }]}>Lease Details</Text>
      </View>

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.cardHeader}>
            <Text style={[styles.listingTitle, { color: colors.text }]}>{getListingTitle()}</Text>
            <View style={[styles.statusBadge, { backgroundColor: `${Colors.sage}25` }]}>
              <Text style={[styles.statusText, { color: Colors.sage }]}>{lease.status}</Text>
            </View>
          </View>
          {getAddress() ? (
            <View style={styles.infoRow}>
              <HabixaIcon name="map-marker-alt" size={14} color={Colors.sage} solid />
              <Text style={[styles.infoText, { color: colors.textSecondary }]}>{getAddress()}</Text>
            </View>
          ) : null}
        </View>

        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Terms</Text>
          <View style={styles.termsGrid}>
            <View style={styles.termRow}>
              <Text style={[styles.termLabel, { color: colors.textSecondary }]}>Start</Text>
              <Text style={[styles.termValue, { color: colors.text }]}>{formatDate(lease.start_date)}</Text>
            </View>
            <View style={styles.termRow}>
              <Text style={[styles.termLabel, { color: colors.textSecondary }]}>End</Text>
              <Text style={[styles.termValue, { color: colors.text }]}>{formatDate(lease.end_date)}</Text>
            </View>
            <View style={styles.termRow}>
              <Text style={[styles.termLabel, { color: colors.textSecondary }]}>Monthly rent</Text>
              <Text style={[styles.termValue, { color: colors.text }]}>{formatCurrency(lease.monthly_rent)}</Text>
            </View>
          </View>
        </View>

        {leasePayments.length > 0 && (
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>Payment history</Text>
            {leasePayments.map((p) => (
              <View
                key={p.id}
                style={[styles.paymentRow, { borderBottomColor: colors.border }]}
              >
                <View>
                  <Text style={[styles.paymentDate, { color: colors.textSecondary }]}>
                    {formatDate(p.created_at)}
                  </Text>
                  <Text
                    style={[
                      styles.paymentStatus,
                      {
                        color:
                          p.status === 'completed'
                            ? Colors.sage
                            : p.status === 'pending'
                              ? Colors.gold
                              : colors.textSecondary,
                      },
                    ]}
                  >
                    {p.status}
                  </Text>
                </View>
                <Text style={[styles.paymentAmount, { color: colors.text }]}>
                  {formatCurrency(p.amount)}
                </Text>
              </View>
            ))}
          </View>
        )}

        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Parties</Text>
          <View style={styles.partyRow}>
            <Text style={[styles.partyLabel, { color: colors.textSecondary }]}>Landlord</Text>
            <Text style={[styles.partyValue, { color: colors.text }]}>
              {lease.landlord?.name ?? `User #${lease.landlord_id}`}
            </Text>
          </View>
          <View style={styles.partyRow}>
            <Text style={[styles.partyLabel, { color: colors.textSecondary }]}>Tenant</Text>
            <Text style={[styles.partyValue, { color: colors.text }]}>
              {lease.tenant?.name ?? `User #${lease.tenant_id}`}
            </Text>
          </View>
        </View>

        {canConfirm ? (
          <Pressable
            style={[styles.confirmBtn, confirming && styles.confirmBtnDisabled]}
            onPress={handleConfirm}
            disabled={confirming}
          >
            {confirming ? (
              <ActivityIndicator size="small" color={Colors.desertSand} />
            ) : (
              <Text style={styles.confirmBtnText}>Confirm lease</Text>
            )}
          </Pressable>
        ) : null}

        {canPayRent && lease ? (
          <Pressable
            style={styles.payRentBtn}
            onPress={() =>
              router.push({
                pathname: '/modal/pay-rent',
                params: {
                  leaseId: String(lease.id),
                  amount: String(lease.monthly_rent),
                  currency: lease.listing?.currency ?? 'USD',
                  landlordName: lease.landlord?.name ?? '',
                },
              })
            }
          >
            <HabixaIcon name="credit-card" size={16} color={Colors.desertSand} solid />
            <Text style={styles.payRentBtnText}>Pay rent</Text>
          </Pressable>
        ) : null}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
    borderBottomWidth: 0.5,
  },
  backBtn: { marginRight: 16 },
  backText: { fontFamily: Fonts.heading, fontSize: 16 },
  title: { fontFamily: Fonts.display, fontSize: 20, flex: 1 },
  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 40 },
  emptyTitle: { fontFamily: Fonts.heading, fontSize: 18, marginTop: 16, textAlign: 'center' },
  scroll: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 100, gap: 16 },
  card: {
    padding: 16,
    borderRadius: 12,
    borderWidth: 0.5,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  listingTitle: { fontFamily: Fonts.heading, fontSize: 17 },
  statusBadge: { paddingVertical: 4, paddingHorizontal: 10, borderRadius: 8 },
  statusText: { fontSize: 10, fontFamily: Fonts.heading, textTransform: 'capitalize' },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 8 },
  infoText: { fontFamily: Fonts.body, fontSize: 13 },
  sectionTitle: { fontFamily: Fonts.heading, fontSize: 14, marginBottom: 12 },
  termsGrid: { gap: 10 },
  termRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  termLabel: { fontFamily: Fonts.body, fontSize: 13 },
  termValue: { fontFamily: Fonts.heading, fontSize: 14 },
  partyRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6 },
  partyLabel: { fontFamily: Fonts.body, fontSize: 13 },
  partyValue: { fontFamily: Fonts.heading, fontSize: 14 },
  paymentRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 0.5,
  },
  paymentDate: { fontFamily: Fonts.body, fontSize: 13 },
  paymentStatus: { fontFamily: Fonts.heading, fontSize: 11, textTransform: 'capitalize', marginTop: 2 },
  paymentAmount: { fontFamily: Fonts.heading, fontSize: 14 },
  confirmBtn: {
    backgroundColor: Colors.terracotta,
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  confirmBtnDisabled: { opacity: 0.6 },
  confirmBtnText: { fontFamily: Fonts.heading, fontSize: 16, color: Colors.desertSand },
  payRentBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.sage,
    paddingVertical: 16,
    borderRadius: 12,
  },
  payRentBtnText: { fontFamily: Fonts.heading, fontSize: 16, color: Colors.desertSand },
});

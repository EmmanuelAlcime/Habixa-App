import { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, Pressable, ScrollView, ActivityIndicator } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useTheme } from '@/context/ThemeContext';
import { HabixaIcon } from '@/components/HabixaIcon';
import { Colors, Fonts } from '@/constants/theme';
import { api, Endpoints } from '@/lib/api/client';

interface Participant {
  id: number;
  name: string;
  initials: string;
  avatar_bg: string;
}

export default function ApplicantsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [messageLoadingId, setMessageLoadingId] = useState<number | null>(null);

  const fetchParticipants = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    setError(null);
    try {
      const res = await api.get<{ participants: Participant[] }>(
        Endpoints.listings.conversationParticipants(id)
      );
      const data = (res as { participants?: Participant[] })?.participants ?? [];
      setParticipants(Array.isArray(data) ? data : []);
    } catch (e: unknown) {
      const err = e as { message?: string };
      setError(err?.message ?? 'Failed to load applicants');
      setParticipants([]);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchParticipants();
  }, [fetchParticipants]);

  async function handleMessage(participant: Participant) {
    if (!id) return;
    setMessageLoadingId(participant.id);
    try {
      const res = await api.post<{ id: number }>(Endpoints.conversations.store(), {
        listing_id: Number(id),
        participant_id: participant.id,
      });
      const conversationId = res?.id ?? (res as { data?: { id?: number } })?.data?.id;
      if (conversationId) {
        router.push(`/(tabs)/(messages)/${conversationId}`);
      }
    } catch (e: unknown) {
      const err = e as { message?: string };
      console.warn('Failed to create conversation:', err?.message);
    } finally {
      setMessageLoadingId(null);
    }
  }

  return (
    <View style={[styles.container, { paddingTop: insets.top, backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Text style={styles.backText}>← Back</Text>
        </Pressable>
        <Text style={styles.title}>Applicants</Text>
      </View>

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator size="large" color={Colors.terracotta} />
        </View>
      ) : error ? (
        <View style={styles.center}>
          <Text style={[styles.errorText, { color: colors.text }]}>{error}</Text>
        </View>
      ) : participants.length === 0 ? (
        <View style={styles.center}>
          <HabixaIcon name="users" size={48} color={Colors.muted} />
          <Text style={[styles.emptyText, { color: colors.text }]}>No applicants yet</Text>
          <Text style={[styles.emptySub, { color: Colors.muted }]}>
            People who message about this listing will appear here
          </Text>
        </View>
      ) : (
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 40 }]}
          showsVerticalScrollIndicator={false}
        >
          {participants.map((p) => (
            <View
              key={p.id}
              style={[styles.row, { backgroundColor: colors.card, borderColor: colors.border }]}
            >
              <View style={[styles.avatar, { backgroundColor: p.avatar_bg || 'rgba(194,103,58,0.15)' }]}>
                <Text style={[styles.avatarText, { color: colors.text }]}>{p.initials}</Text>
              </View>
              <View style={styles.rowBody}>
                <Text style={[styles.name, { color: colors.text }]}>{p.name}</Text>
              </View>
              <Pressable
                style={styles.msgBtn}
                onPress={() => handleMessage(p)}
                disabled={messageLoadingId === p.id}
              >
                {messageLoadingId === p.id ? (
                  <ActivityIndicator size="small" color={Colors.desertSand} />
                ) : (
                  <>
                    <HabixaIcon name="comment" size={12} color={Colors.desertSand} />
                    <Text style={styles.msgBtnText}>Message</Text>
                  </>
                )}
              </Pressable>
            </View>
          ))}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: Colors.midnightInk,
  },
  backBtn: {
    marginRight: 16,
  },
  backText: {
    fontFamily: Fonts.heading,
    fontSize: 16,
    color: Colors.terracotta,
  },
  title: {
    fontFamily: Fonts.display,
    fontSize: 22,
    color: Colors.desertSand,
  },
  center: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  errorText: {
    fontFamily: Fonts.body,
    fontSize: 15,
  },
  emptyText: {
    fontFamily: Fonts.heading,
    fontSize: 18,
    marginTop: 12,
  },
  emptySub: {
    fontFamily: Fonts.body,
    fontSize: 14,
    marginTop: 8,
    textAlign: 'center',
  },
  scroll: {
    flex: 1,
  },
  list: {
    padding: 20,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 12,
    borderWidth: 0.5,
    marginBottom: 8,
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontFamily: Fonts.heading,
    fontSize: 15,
  },
  rowBody: {
    flex: 1,
    marginLeft: 12,
  },
  name: {
    fontFamily: Fonts.heading,
    fontSize: 15,
  },
  msgBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: Colors.terracotta,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 10,
  },
  msgBtnText: {
    fontFamily: Fonts.heading,
    fontSize: 13,
    color: Colors.desertSand,
  },
});

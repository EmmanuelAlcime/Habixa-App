import { useState, useEffect, useCallback } from 'react';
import { api, Endpoints } from '@/lib/api/client';
import type { Listing } from '@/lib/types/listing';
import { mapApiListing, type ApiListing } from '@/lib/types/listing';

export interface LandlordProfile {
  id: number;
  name: string;
  bio?: string | null;
  avatar_url?: string | null;
  created_at?: string | null;
  landlord_score?: { score: number; review_count: number } | null;
  active_listings_count?: number;
}

export interface LandlordReview {
  id: number;
  author_id: number;
  subject_id: number;
  type: string;
  rating: number;
  content?: string | null;
  created_at: string;
  author?: { id: number; name: string };
}

interface LandlordProfileState {
  profile: LandlordProfile | null;
  reviews: LandlordReview[];
  listings: Listing[];
  loading: boolean;
  error: string | null;
  refetch: () => Promise<void>;
}

export function useLandlordProfile(idOrSlug: string | undefined): LandlordProfileState {
  const [profile, setProfile] = useState<LandlordProfile | null>(null);
  const [reviews, setReviews] = useState<LandlordReview[]>([]);
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAll = useCallback(async () => {
    if (!idOrSlug) {
      setProfile(null);
      setReviews([]);
      setListings([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const profileRes = await api.get<LandlordProfile>(Endpoints.landlords.show(idOrSlug), { skipAuth: true });
      setProfile(profileRes);

      const userId = String(profileRes.id);
      const [reviewsRes, listingsRes] = await Promise.all([
        api.get<{ data?: LandlordReview[] } | LandlordReview[]>(Endpoints.usersReviews(userId), {
          skipAuth: true,
        }).catch(() => ({ data: [] })),
        api
          .get<{ data?: ApiListing[] }>(Endpoints.listings.index({ user_id: userId }), { skipAuth: true })
          .then((r) => r.data ?? [])
          .catch(() => []),
      ]);

      const reviewsData = Array.isArray(reviewsRes) ? reviewsRes : reviewsRes?.data ?? [];
      setReviews(reviewsData as LandlordReview[]);

      const listingsData = Array.isArray(listingsRes) ? listingsRes : listingsRes ?? [];
      const mapped = (listingsData as ApiListing[]).map(mapApiListing);
      setListings(mapped);
    } catch (e) {
      const err = e as { message?: string; status?: number };
      if (err?.status === 404) {
        setError('Landlord not found');
      } else {
        setError(err?.message ?? 'Failed to load profile');
      }
      setProfile(null);
      setReviews([]);
      setListings([]);
    } finally {
      setLoading(false);
    }
  }, [idOrSlug]);

  useEffect(() => {
    if (idOrSlug) {
      fetchAll();
    } else {
      setProfile(null);
      setReviews([]);
      setListings([]);
      setLoading(false);
    }
  }, [idOrSlug, fetchAll]);

  return { profile, reviews, listings, loading, error, refetch: fetchAll };
}

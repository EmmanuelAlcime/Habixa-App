const appJson = require('./app.json');

const googleMapsKey =
  process.env.EXPO_PUBLIC_GOOGLE_MAPS_API_KEY || process.env.GOOGLE_MAPS_API_KEY || '';

module.exports = {
  ...appJson,
  expo: {
    ...appJson.expo,
    android: {
      ...appJson.expo.android,
      package: 'com.habixa.app',
      config: {
        ...appJson.expo.android?.config,
        googleMaps: {
          apiKey: googleMapsKey,
        },
      },
    },
    ios: {
      ...appJson.expo.ios,
      bundleIdentifier: 'com.habixa.app',
      config: {
        ...appJson.expo.ios?.config,
        googleMapsApiKey: googleMapsKey,
      },
    },
    plugins: [
      ...(appJson.expo.plugins || []),
      '@react-native-community/datetimepicker',
      'expo-localization',
      [
        '@stripe/stripe-react-native',
        {
          merchantIdentifier: 'merchant.com.habixa.app',
          enableGooglePay: true,
        },
      ],
    ],
  },
};
